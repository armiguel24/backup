#Scripts para entrega de los tres ejercicios
